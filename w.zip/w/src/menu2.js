const menu2 = (prefix) => { 
	return `                 
⚠️menu em construção `
}
exports.menu2 = menu2
