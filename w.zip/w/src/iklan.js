const iklan = () => { 
	return `           
poha de pagar pra ter bot so dar $(prefix)dono e pedir
`
}
exports.iklan = iklan
