const daftarvip = (prefix) => { 
	return `
	
*PREÇO DE LISTA VIP :*

*pagar e o garai so vim pv e pedi

*SE QUER REGISTAR VIP :*

*Proprietário do bate-papo BOT :*

_wa.me/558498198074 ou digite *${prefix}owner*_

*NOTA*

*GRUPO DO BOT :*
_sem ainda_ `
}
exports.daftarvip = daftarvip
