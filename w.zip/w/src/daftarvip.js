const daftarvip = (prefix) => { 
	return `
	
*PREÇO DE LISTA VIP :*

*pagar e o garai so vim pv e pedi

*SE QUER REGISTAR VIP :*

*Proprietário do bate-papo BOT :*

_wa.me/5511934713306 ou digite *${prefix}owner*_

*NOTA*

*GRUPO DO BOT :*
𝑁𝑁 𝑇𝐸𝑀 `
}
exports.daftarvip = daftarvip
