const lista = () => { 
	return `
	𝐵𝑅𝑈𝑋𝐼𝑁𝐻𝑂 𝑀𝑂𝐷𝑆 𝑊𝐴𝑅`
}
exports.lista = lista
