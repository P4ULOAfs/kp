const help = (prefix) => {
	return `
Ola 👋 *${pushname2}*
Eu sou o bot daqui aqui meus comandos 
aproveite 😀 e sem flood
┎─────────────────────┒
║ ──────◤MAIS USADOS◢────
║ ➲*${prefix}Sticker* [Faz figurinha]
║ ➲*${prefix}play* [nome da música]
║ ➲*${prefix}toimg* [converter figurinha em imagem]
║ ➲*${prefix}wame* [link do seu whatsapp]
║ ➲*${prefix}tts pt* [seu texto]
║ ─────◤SOMENTE GRUPOS◢────
║ ➲*${prefix}closegc* [fechar grupo]
║ ➲ *${prefix}opengc* [abrir grupo]
║ ➲ *${prefix}antilink* 1 [anti link]
║ ➲ *${prefix}antiracismo on* [anti racismo]
║ ➲ *${prefix}banir* [banir membro]
║ ➲ *${prefix}admins* [lista se administradores]
║ ➲ *${prefix}marcar* [marcar todos membros]
║ ➲ *${prefix}linkgp* [link do grupo]
║ ➲ *${prefix}promover* [dar adm]
║ ➲ *${prefix}rebaixar* [tirar adm]
║ ➲ *${prefix}bemvindo* 1 [recusso de boas vindas]
║ ➲ *${prefix}grupoinfo* [info]
║ ➲ *${prefix}setdesc* [trocar descrição]
║ ➲ *${prefix}setfoto* [mudar foto]
║ ➲ *${prefix}porno* [porno]
║ ➲ *${prefix}mia* [fotos da mia]
║ ➲  *${prefix}linkgp*
║ ➲  *${prefix}simih [1/0]*
║ ➲  *${prefix}marcar*
║ ➲  *${prefix}add [@]*
║ ➲  *${prefix}banir [@]*
║ ➲  *${prefix}promover [@]*
║ ➲  *${prefix}rebaixar*
║ ➲  *${prefix}admins*
║ ➲ *${prefix}marcar*
║ ➲  *${prefix}marcar2*
║ ➲ *${prefix}marcar3*
║ ➲ *${prefix}bemvindo [1/0]*
║ ➲ *${prefix}bomdia*
║ ➲ *${prefix}boanoite*
║ ➲ *${prefix}setfoto*
║ ➲ *${prefix}grupoinfo*
║ ────◤INTERAGIR◢────────
║ ➲ *${prefix}figu*
║ ➲ *${prefix}toimg*
║ ➲ *${prefix}nabutojokes (memes aleatórios)*
║ ➲ *${prefix}memeindo*
║ ➲ *${prefix}tts*
║ ➲ *${prefix}lolih [on]*
║ ➲ *${prefix}nsfwloli [off]*
║ ➲ *${prefix}url2img*
║ ➲ *${prefix}leens [na legenda]*
║ ➲ *${prefix}wait [na legenda]*
║ ────◤CMDS DE IMAGEM◢────
║ ➲ *${prefix}loli* [off]
║ ➲ *${prefix}loli1*
║ ➲ *${prefix}hentai*
║ ➲ *${prefix}dono*
║ ➲ *${prefix}porno*
║ ➲ *${prefix}boanoite*
║ ➲ *${prefix}bomdia*
║ ➲ *${prefix}boatarde*
║ ➲ *${prefix}mia [aleatórias]*
║ ➲ *${prefix}rize [aleatórias]*
║ ➲ *${prefix}minato [aleatórias]*
║ ➲ *${prefix}boruto [aleatórias]*
║ ➲ *${prefix}hinata [aleatórias]*
║ ➲ *${prefix}sasuke [aleatórias]*
║ ➲ *${prefix}sakura [aleatórias]*
║ ➲ *${prefix}naruto [aleatórias]*
║ ➲ *${prefix}meme*   
║ ➲ *${prefix}lofi*
║ ➲ *${prefix}malkova*
║ ➲ *${prefix}canal*
║ ➲ *${prefix}nsfwloli1*
║ ➲ *${prefix}reislin*
║─────◤INTELIGENCIA◢────
║ ➲ *${prefix}simih 1 (para ativar)*
║ ➲ *${prefix}simih 0 (para desativar)*
║ ➲ *${prefix}simi (sua mensagem)*
║ ─────◤Premium◢─────
║ ➲ *${prefix}dado*
║ ➲ *${prefix}cekvip*
║ ➲ *${prefix}premiumlist*
║ ➲ *${prefix}delete*
║ ➲ *${prefix}modapk*
║ ➲ *${prefix}indo10*
║ ➲ *${prefix}daftarvip [para virar Premium]*
║ ➲ *${prefix}qrcode*
║ ➲ *${prefix}chentai*
║ ➲ *${prefix}gcpf*
║ ➲ *${prefix}gbin*
║ ➲ *${prefix}pack*
║ ➲ *${prefix}destrava*
║ ➲ *${prefix}gpessoa*
║ ─────◤OUTROS◢─────
║ ➲ *${prefix}neko*
║ ➲ *${prefix}ttp [texto]*
║ ➲ *${prefix}testime*
║ ➲ *${prefix}tomp3*
║ ➲ *${prefix}modoanime [on/off]*
║ ➲ *${prefix}modonsfw [on/off]*
║ ➲ *${prefix}happymod [jogo/app]*
║ ➲ *${prefix}rize*
║ ➲ *${prefix}ytsearch*
║ ➲ *${prefix}moddroid [jogo/app]*
║ ➲ *${prefix}xvideos [titulo]**
║ ➲ *${prefix}nomegp*
║ ➲ *${prefix}nabutojokes (memes aleatórios)*
║ ➲ *${prefix}animecry*
║ ➲ *${prefix}gay1*
║ ➲ *${prefix}next*
║ ➲ *${prefix}alerta*
║ ➲ *${prefix}belle [img aleatórias]*
║ ➲ *${prefix}pronomeneu [texto]*
║ ➲ *${prefix}hobby*
┖──────────────────┚
tmj , espero que goste 😀`
}

exports.help = help



