const help = (prefix,) => { 
	return `                 

├─────────┓
│ᏟϴᎷᎪΝᎠϴՏ 
├────────
│ᎬХᏟᏞႮՏᏆᏙϴ ᏢᎪᎡᎪ ᎪᎠᎷ'Տ
│ ╭──────────────────
│ ║├> ${prefix}modoanime [on/off]
│ ║├────>ativa/desativa o modo anime 
│ ║├> ${prefix}antiracismo [on/off]
│ ║├────>ativa/desativa o antiracismo
│ ║├> ${prefix}modonsfw [on/off]
│ ║├────>ativa/desativa o modonsfw
│ ║├> ${prefix}setdesc
│ ║├────> muda a desc
│ ║├> ${prefix}delete
│ ║├────> apaga a msg marcada
│ ║├> ${prefix}setfoto
│ ║├────> muda ft do gp
│ ║├> ${prefix}setnome
│ ║├────> muda nome do gp
│ ║├> ${prefix}leveling [on/off]
│ ║├────> Ativa/desativa o level
│ ║├> ${prefix}antilink [1/0]
│ ║├────> ativa/desativa o antilink
│ ║├> ${prefix}closegc
│ ║├────> fecha o gp
│ ║├> ${prefix}opengc
│ ║├────> abre o gp
│ ║├> ${prefix}marcar
│ ║├────> marca td mundo
│ ║├> ${prefix}promover
│ ║├────> promove a adm
│ ║├> ${prefix}rebaixar 
│ ║├────> rebaixa a membro comum
│ ║├> ${prefix}add ex:558499278703
│ ║├────> adc no gp
│ ║├> ${prefix}banir @
│ ║├────> bani do gp
│ ║├> ${prefix}linkgp
│ ║├────> manda o link do gp
│ ║├> ${prefix}simih [1/0]
│ ║├────> o bot conversa no gp
│ ║├> ${prefix}bemvindo[1/0]
│ ║├────> msg de bem vindo
├────────
│  ᎠϴᏔΝᏞϴᎪᎠ/ᏞᏆΝᏦ
│ ╭──────────────────
│ ║├> ${prefix}ytmp4 (link)
│ ║├────>baixa video/áudio
│ ║├> ${prefix}ytmp3 (link)
│ ║├────>baixa video/áudio
│ ║├> ${prefix}ytmp (link)
│ ║├────>baixa video/áudio
│ ║├> ${prefix}playmp3 (nome)
│ ║├────>baixa video/áudio
│ ║├> ${prefix}play (nome)
│ ║├────>baixa video/áudio
│ ║├> ${prefix}tiktok (link)
│ ║├────>baixa video/áudio
├────────
│STALK
│ ╭───────────────────
│ ║├> ${prefix}igstalk
│ ║├────>stak insta
│ ║├> ${prefix}tiktokstalk
│ ║├────>stalk tik bosta
├────────
│ᎷᏆᎠᏆᎪ/ϴႮͲᎡϴՏ
│ ╭───────────────────
│ ║├> ${prefix}f
│ ║├> ${prefix}fig
│ ║├> ${prefix}figu
│ ║├────>fazer fig cm foto/gif
│ ║├> ${prefix}tts (codigo do país)
│ ║├────>google fala
│ ║├> ${prefix}toimg
│ ║├────>tranforma figu em ft
│ ║├> ${prefix}wait
│ ║├────>pesquisa por anime na ft
│ ║├> ${prefix}infogc
│ ║├────>info do gp
│ ║├> ${prefix}pokemon
│ ║├────>pokemon aleatório
├────────
│LOGO
│ ╭───────────────────
│ ║├> ${prefix}xd
│ ║├────>logo com seu txt
│ ║├> ${prefix}wolflogo2 <texto | texto>
│ ║├────>logo com seu txt
│ ║├> ${prefix}galaxtest
│ ║├────>logo com seu txt
│ ║├> ${prefix}lovemake
│ ║├────>logo com seu txt
│ ║├> ${prefix}stiltext
│ ║├────>logo com seu txt
│ ║├> ${prefix}ninjalogo
│ ║├────>logo com seu txt
│ ║├> ${prefix}party
│ ║├────>logo com seu txt
│ ║├> ${prefix}water
│ ║├────>logo com seu txt
│ ║├> ${prefix}lionlogo <texto | texto>
│ ║├────>logo com seu txt
│ ║├> ${prefix}textscreen
│ ║├────>logo com seu txt
│ ║├> ${prefix}text3d
│ ║├────>logo com seu txt
│ ║├> ${prefix}marvelogo <texto | texto>
│ ║├────>logo com seu txt
│ ║├> ${prefix}snow <texto | texto>
│ ║├────>logo com seu txt
│ ║├> ${prefix}firetext
│ ║├────>logo com seu txt
├────────
│INFO BOT
│ ╭───────────────────
│ ║├> ${prefix}info
│ ║├────>informações do bot
│ ║├> ${prefix}bloqueados
│ ║├────>cntt bloqueado
│ ║├> ${prefix}.dono
│ ║├────>info do dono
│ ║├> ${prefix}infogc
│ ║├────>info do gp
├────────
│ᏟϴᎷᎪΝᎠϴՏ Ꭰϴ ᏟᎡᏆᎪᎠϴᎡ
│ ╭───────────────────
│ ║├> ${prefix}setprefix
│ ║├────>altera o prefixo
│ ║├> ${prefix}limpar
│ ║├────>limpa o chat de conversas
│ ║├> ${prefix}bc
│ ║├────>faz uma tm
│ ║├> ${prefix}bloquear
│ ║├────>bloqueia
│ ║├> ${prefix}desbloquear
│ ║├────>desbloqueia
│ ║├> ${prefix}setnomebot
│ ║├────>muda o nome do bot
│ ║├> ${prefix}mining
│ ║├────>
│ ║├> ${prefix}totaluser
│ ║├────>total de usuários
│ ║├> ${prefix}desligar
│ ║├────>desliga o bot
│ ║├> ${prefix}setppbot
│ ║├────>muda a ft
├────────
│caso encontre um erro bug use o ${prefix} bug e │reporte
│de resto espero que goste
│e em breve mais comandos
├─────────┛

`
}
exports.help = help



  
